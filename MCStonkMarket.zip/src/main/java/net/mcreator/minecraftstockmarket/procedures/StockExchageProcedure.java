package net.mcreator.minecraftstockmarket.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.Mth;

import net.mcreator.minecraftstockmarket.network.MinecraftstockmarketModVariables;

import javax.annotation.Nullable;

import java.util.Random;

@Mod.EventBusSubscriber
public class StockExchageProcedure {
	@SubscribeEvent
	public static void onWorldTick(TickEvent.WorldTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.world);
		}
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		MinecraftstockmarketModVariables.WorldVariables.get(world).tickDelay = MinecraftstockmarketModVariables.WorldVariables.get(world).tickDelay
				+ 1;
		MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
		if (MinecraftstockmarketModVariables.WorldVariables.get(world).tickDelay >= 20) {
			MinecraftstockmarketModVariables.WorldVariables.get(
					world).VNNStocks = MinecraftstockmarketModVariables.WorldVariables.get(world).VNNStocks + 5 * Mth.nextInt(new Random(), -8, 10);
			MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
			if (MinecraftstockmarketModVariables.WorldVariables.get(world).VNNStocks < 1) {
				MinecraftstockmarketModVariables.WorldVariables.get(world).VNNStocks = 1;
				MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
			}
			MinecraftstockmarketModVariables.WorldVariables.get(
					world).PIGStocks = MinecraftstockmarketModVariables.WorldVariables.get(world).PIGStocks + 5 * Mth.nextInt(new Random(), -8, 10);
			MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
			if (MinecraftstockmarketModVariables.WorldVariables.get(world).PIGStocks < 1) {
				MinecraftstockmarketModVariables.WorldVariables.get(world).PIGStocks = 1;
				MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
			}
			MinecraftstockmarketModVariables.WorldVariables.get(
					world).BHTStocks = MinecraftstockmarketModVariables.WorldVariables.get(world).BHTStocks + 5 * Mth.nextInt(new Random(), -8, 10);
			MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
			if (MinecraftstockmarketModVariables.WorldVariables.get(world).BHTStocks < 1) {
				MinecraftstockmarketModVariables.WorldVariables.get(world).BHTStocks = 1;
				MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
			}
			MinecraftstockmarketModVariables.MapVariables.get(world).EGGStocks = MinecraftstockmarketModVariables.MapVariables.get(world).EGGStocks
					+ 5 * Mth.nextInt(new Random(), -8, 10);
			MinecraftstockmarketModVariables.MapVariables.get(world).syncData(world);
			if (MinecraftstockmarketModVariables.WorldVariables.get(world).BHTStocks < 1) {
				MinecraftstockmarketModVariables.WorldVariables.get(world).BHTStocks = 1;
				MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
			}
			MinecraftstockmarketModVariables.WorldVariables.get(world).tickDelay = 0;
			MinecraftstockmarketModVariables.WorldVariables.get(world).syncData(world);
		}
	}
}
