
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftstockmarket.init;

import net.minecraftforge.network.IContainerFactory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.mcreator.minecraftstockmarket.world.inventory.VNNMenu;
import net.mcreator.minecraftstockmarket.world.inventory.StockMarketMenu;
import net.mcreator.minecraftstockmarket.world.inventory.PIGMenu;
import net.mcreator.minecraftstockmarket.world.inventory.EGGMenu;
import net.mcreator.minecraftstockmarket.world.inventory.BHTMenu;
import net.mcreator.minecraftstockmarket.world.inventory.AtmScreenMenu;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MinecraftstockmarketModMenus {
	private static final List<MenuType<?>> REGISTRY = new ArrayList<>();
	public static final MenuType<StockMarketMenu> STOCK_MARKET = register("stock_market",
			(id, inv, extraData) -> new StockMarketMenu(id, inv, extraData));
	public static final MenuType<VNNMenu> VNN = register("vnn", (id, inv, extraData) -> new VNNMenu(id, inv, extraData));
	public static final MenuType<PIGMenu> PIG = register("pig", (id, inv, extraData) -> new PIGMenu(id, inv, extraData));
	public static final MenuType<BHTMenu> BHT = register("bht", (id, inv, extraData) -> new BHTMenu(id, inv, extraData));
	public static final MenuType<EGGMenu> EGG = register("egg", (id, inv, extraData) -> new EGGMenu(id, inv, extraData));
	public static final MenuType<AtmScreenMenu> ATM_SCREEN = register("atm_screen", (id, inv, extraData) -> new AtmScreenMenu(id, inv, extraData));

	private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
		MenuType<T> menuType = new MenuType<T>(containerFactory);
		menuType.setRegistryName(registryname);
		REGISTRY.add(menuType);
		return menuType;
	}

	@SubscribeEvent
	public static void registerContainers(RegistryEvent.Register<MenuType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MenuType[0]));
	}
}
