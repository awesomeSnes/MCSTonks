
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftstockmarket.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.minecraftstockmarket.item.VNNStonkItem;
import net.mcreator.minecraftstockmarket.item.TabletItem;
import net.mcreator.minecraftstockmarket.item.PIGStonkItem;
import net.mcreator.minecraftstockmarket.item.EGGStonkItem;
import net.mcreator.minecraftstockmarket.item.DollarItem;
import net.mcreator.minecraftstockmarket.item.BHTStonkItem;
import net.mcreator.minecraftstockmarket.MinecraftstockmarketMod;

public class MinecraftstockmarketModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MinecraftstockmarketMod.MODID);
	public static final RegistryObject<Item> TABLET = REGISTRY.register("tablet", () -> new TabletItem());
	public static final RegistryObject<Item> DOLLAR = REGISTRY.register("dollar", () -> new DollarItem());
	public static final RegistryObject<Item> ATM = block(MinecraftstockmarketModBlocks.ATM, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> VNN_STONK = REGISTRY.register("vnn_stonk", () -> new VNNStonkItem());
	public static final RegistryObject<Item> PIG_STONK = REGISTRY.register("pig_stonk", () -> new PIGStonkItem());
	public static final RegistryObject<Item> BHT_STONK = REGISTRY.register("bht_stonk", () -> new BHTStonkItem());
	public static final RegistryObject<Item> EGG_STONK = REGISTRY.register("egg_stonk", () -> new EGGStonkItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
