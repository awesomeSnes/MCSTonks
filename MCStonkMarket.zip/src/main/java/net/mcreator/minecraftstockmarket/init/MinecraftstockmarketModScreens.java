
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftstockmarket.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.minecraftstockmarket.client.gui.VNNScreen;
import net.mcreator.minecraftstockmarket.client.gui.StockMarketScreen;
import net.mcreator.minecraftstockmarket.client.gui.PIGScreen;
import net.mcreator.minecraftstockmarket.client.gui.EGGScreen;
import net.mcreator.minecraftstockmarket.client.gui.BHTScreen;
import net.mcreator.minecraftstockmarket.client.gui.AtmScreenScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MinecraftstockmarketModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(MinecraftstockmarketModMenus.STOCK_MARKET, StockMarketScreen::new);
			MenuScreens.register(MinecraftstockmarketModMenus.VNN, VNNScreen::new);
			MenuScreens.register(MinecraftstockmarketModMenus.PIG, PIGScreen::new);
			MenuScreens.register(MinecraftstockmarketModMenus.BHT, BHTScreen::new);
			MenuScreens.register(MinecraftstockmarketModMenus.EGG, EGGScreen::new);
			MenuScreens.register(MinecraftstockmarketModMenus.ATM_SCREEN, AtmScreenScreen::new);
		});
	}
}
