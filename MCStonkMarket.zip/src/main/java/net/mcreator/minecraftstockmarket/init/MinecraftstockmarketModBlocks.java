
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftstockmarket.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.minecraftstockmarket.block.ATMBlock;
import net.mcreator.minecraftstockmarket.MinecraftstockmarketMod;

public class MinecraftstockmarketModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MinecraftstockmarketMod.MODID);
	public static final RegistryObject<Block> ATM = REGISTRY.register("atm", () -> new ATMBlock());
}
